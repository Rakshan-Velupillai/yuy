// JavaScript file to handle any future dynamic interactions or validations
document.getElementById("bonafideForm").addEventListener("submit", function(event) {
    alert("Bonafide data has been submitted!");
  });
  